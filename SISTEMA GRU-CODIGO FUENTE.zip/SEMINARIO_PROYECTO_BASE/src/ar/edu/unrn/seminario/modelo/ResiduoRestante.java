package ar.edu.unrn.seminario.modelo;

import ar.edu.unrn.seminario.exception.NotNullException;

public class ResiduoRestante extends Residuo{

	public ResiduoRestante(TipoResiduo residuo, double cantKg) throws NotNullException {
		super(residuo, cantKg);
		
	}

}
