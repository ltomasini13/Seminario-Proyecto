package ar.edu.unrn.seminario.exception;

public class AuthenticationException extends Exception{
	public AuthenticationException () {
		
	}
	
	
	public AuthenticationException (String message) {
		super(message);
	}

}
