package ar.edu.unrn.seminario.exception;

public class CreationValidationException extends Exception {

	
	public CreationValidationException () {
			
		}
	
	
	public CreationValidationException (String message) {
		super(message);
	}
}
