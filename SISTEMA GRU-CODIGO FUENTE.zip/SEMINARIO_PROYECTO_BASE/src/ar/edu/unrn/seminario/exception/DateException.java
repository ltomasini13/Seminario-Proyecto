package ar.edu.unrn.seminario.exception;

public class DateException extends Exception{

	public DateException () {
		
	}


	public DateException (String message) {
		super(message);
	}
}
