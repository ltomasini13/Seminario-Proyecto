package ar.edu.unrn.seminario.exception;

public class SintaxisSQLException extends Exception {
		public SintaxisSQLException () {
			
		}
		
		
		public SintaxisSQLException (String message) {
			super(message);
		}
}
