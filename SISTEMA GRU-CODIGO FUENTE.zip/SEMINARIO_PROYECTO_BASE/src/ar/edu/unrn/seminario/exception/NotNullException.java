package ar.edu.unrn.seminario.exception;

public class NotNullException extends Exception{
	public NotNullException () {
	
	}
	public NotNullException (String message) {
		super(message);
	}

}
