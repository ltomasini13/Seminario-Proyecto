package ar.edu.unrn.seminario.exception;

public class DataEmptyException extends Exception{
	public DataEmptyException () {
		
	}
	
	
	public DataEmptyException (String message) {
		super(message);
	}

}
