package ar.edu.unrn.seminario.api;

import java.util.List;


import ar.edu.unrn.seminario.dto.CiudadanoDTO;

import ar.edu.unrn.seminario.dto.BeneficioDTO;
import ar.edu.unrn.seminario.dto.Campa�aDTO;
import ar.edu.unrn.seminario.dto.CiudadanoDTO;
import ar.edu.unrn.seminario.dto.OrdenDeRetiroDTO;
import ar.edu.unrn.seminario.dto.PedidoRetiroDTO;
import ar.edu.unrn.seminario.dto.RecolectorDTO;
import ar.edu.unrn.seminario.dto.ResiduoARetirarDTO;
import ar.edu.unrn.seminario.dto.ResiduoDTO;
import ar.edu.unrn.seminario.dto.ResiduoRestanteDTO;
import ar.edu.unrn.seminario.dto.ResiduoRetiradoDTO;
import ar.edu.unrn.seminario.dto.RolDTO;
import ar.edu.unrn.seminario.dto.UsuarioDTO;
import ar.edu.unrn.seminario.dto.VisitaDTO;
import ar.edu.unrn.seminario.dto.ViviendaDTO;
import ar.edu.unrn.seminario.exception.AppException;
import ar.edu.unrn.seminario.exception.AuthenticationException;
import ar.edu.unrn.seminario.exception.CollectorException;
import ar.edu.unrn.seminario.exception.DataEmptyException;
import ar.edu.unrn.seminario.exception.DateException;
import ar.edu.unrn.seminario.exception.DuplicateUniqueKeyException;
import ar.edu.unrn.seminario.exception.EmptyListException;
import ar.edu.unrn.seminario.exception.NotNullException;
import ar.edu.unrn.seminario.exception.NumbersException;
import ar.edu.unrn.seminario.exception.SintaxisSQLException;
import ar.edu.unrn.seminario.exception.StateException;
import ar.edu.unrn.seminario.exception.WasteException;
import ar.edu.unrn.seminario.exception.ZeroNegativeNumberException;
import ar.edu.unrn.seminario.exception.CreationValidationException;
import ar.edu.unrn.seminario.modelo.ResiduoRestante;
import ar.edu.unrn.seminario.modelo.ResiduoRetirado;
import ar.edu.unrn.seminario.modelo.TipoResiduo;
import ar.edu.unrn.seminario.modelo.Usuario;
import ar.edu.unrn.seminario.modelo.Visita;

public interface IApi {

	void registrarUsuario(String username, String password, String email, String nombre, Integer rol) throws DataEmptyException, NotNullException, SintaxisSQLException;
	void registrarCiudadano(String username, String password, String email, String nombre, Integer rol, String apellido, String dni) throws SintaxisSQLException, DataEmptyException, NotNullException, NumbersException, AuthenticationException;
	
	void loguearUsuario(String username, String contrasena) throws SintaxisSQLException, AuthenticationException, NotNullException, DataEmptyException;
	
	void registrarVivienda(String calle, String numero, String barrio, String latitud, String longitud, String nombreCiudadano, String apeCiudadano,
			String dniCiudadano)throws NotNullException, DataEmptyException, NumbersException, SintaxisSQLException, AuthenticationException;


	void registrarResiduo(String tipo, String numero) throws NumbersException, NotNullException, DataEmptyException, DuplicateUniqueKeyException, SintaxisSQLException;
	
	
	boolean esUsuarioAdmin();
	boolean esUsuarioReciclador();
	UsuarioDTO obtenerUsuario(String username) throws SintaxisSQLException, NotNullException, DataEmptyException;
	void eliminarUsuario(String username);

	List<RolDTO> obtenerRoles() throws SintaxisSQLException;

	List<RolDTO> obtenerRolesActivos();

	void guardarRol(Integer codigo, String descripci�n, boolean estado) throws NotNullException, DataEmptyException; // crear el objeto de dominio �Rol�

	RolDTO obtenerRolPorCodigo(Integer codigo); // recuperar el rol almacenado

	void activarRol(Integer codigo); // recuperar el objeto Rol, implementar el comportamiento de estado.

	void desactivarRol(Integer codigo); // recuperar el objeto Rol, imp

	List<UsuarioDTO> obtenerUsuarios(); // recuperar todos los usuarios

	void activarUsuario(String username) throws StateException; // recuperar el objeto Usuario, implementar el comportamiento de estado.

	void desactivarUsuario(String username) throws StateException ; // recuperar el objeto Usuario, implementar el comportamiento de estado.
	

	List<ViviendaDTO> obtenerViviendas() throws EmptyListException; //recupera todas las viviendas registradas
	ViviendaDTO obtenerVivienda(Integer idVivienda);
	ViviendaDTO obtenerViviendaDelPedido(Integer idPedido);
	List<PedidoRetiroDTO> obtenerPedidos() throws EmptyListException;
	PedidoRetiroDTO obtenerPedidoDeLaOrden(Integer idOrden);

	List<ResiduoDTO> obtenerResiduos();
	void cerrarSesion(); 				
	
	void generarPedido(Integer id_vivienda, boolean cargaPesada, String observacion, List<ResiduoARetirarDTO> residuosARetirar) throws NotNullException, ZeroNegativeNumberException, EmptyListException;
	void registrarVivienda(String calle, String numero, String barrio, String latitud, String longitud) throws DataEmptyException, NumbersException, NotNullException, AuthenticationException;

	void pedidoPendiente(Integer id_vivienda) throws CreationValidationException; //Dispara un error si hay algun pedido que no concluy� para la vievienda pasada por par�metro

	void registrarRecolector(String nombre, String apellido, String dni, String email) throws  NotNullException, DataEmptyException, DuplicateUniqueKeyException, SintaxisSQLException, NumbersException;
	
	List<RecolectorDTO> obtenerRecolectores() throws SintaxisSQLException ;
	
	List<ResiduoARetirarDTO> obtenerResiduosARetirar(Integer idPedido);
	List<ResiduoRetiradoDTO> obtenerResiduosRetirados(Integer idVisita);
	List<ResiduoRestanteDTO> obtenerResiduosRestantes(Integer idPedido);
	List<OrdenDeRetiroDTO> obtenerOrdenes() throws SintaxisSQLException;
	void generarOrden(Integer id_pedido)throws SintaxisSQLException, CreationValidationException ;
	void cancelarOrden(Integer idOrden) throws StateException;
	void concretarOrden(Integer idOrden) throws StateException, SintaxisSQLException;
	
	void asignarRecolector(Integer idOrden, Integer idRecolector);
	void cambiarDue�o(Integer idVivienda, String dni);
	void cambiarDue�o(Integer idVivienda, String nombreCiudadano, String apeCiudadano, String dniCiudadano) throws NotNullException, DataEmptyException, NumbersException;
	List<CiudadanoDTO> obtenerCiudadanos(); 
	CiudadanoDTO obtenerCiudadanoDeLaVivienda(Integer idVivienda);
	
	void agregarVisita(Integer idOrden, String observacion, List<ResiduoRetiradoDTO> residuosretiradosDTO) throws NotNullException, CreationValidationException, StateException, WasteException, CollectorException, SintaxisSQLException;
	List<VisitaDTO> obtenerVisitas() throws EmptyListException;
	List<VisitaDTO> obtenerVisitasDeLaOrden(Integer idOrden) throws EmptyListException;
	OrdenDeRetiroDTO obtenerOrden(Integer idVisita);
	void registrarBeneficio(String nombre, String puntos) throws DataEmptyException, NotNullException, NumbersException, AppException;

	List<BeneficioDTO> obtenerBeneficios()throws AppException, DataEmptyException, NotNullException, NumbersException;
	
	void registrarCampa�a(String nombre, String descripcion) throws DataEmptyException, NotNullException, AppException, DateException, CreationValidationException;
	
	List<Campa�aDTO> obtenerCampa�as()throws AppException, DataEmptyException, NotNullException, DateException;
	
	boolean residuoEstaDeclarado(ResiduoRetiradoDTO residuoRetiradoDto, Integer idOrden);
	double calcularResiduoRestanteDelResiduo(ResiduoRetiradoDTO residuoRetiradoDTO, Integer idOrden);

	

	
	void realizarCanje(Integer idBeneficio, String dni) throws NumbersException, SintaxisSQLException, NotNullException, AppException;
	
	void actualizarPuntaje(double puntaje);
	List<BeneficioDTO> obtenerCatalogo(Integer idCampa�a) throws AppException, NotNullException, DataEmptyException, DateException, NumbersException;
	Campa�aDTO obtenerCampa�aVigente() throws AppException, DateException, NotNullException, DataEmptyException;
	void agregarBeneficio(Integer idCampa�a, Integer idBeneficio) throws AppException, CreationValidationException, DataEmptyException, NotNullException, NumbersException;
	


}
